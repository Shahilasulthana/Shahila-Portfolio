import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FindMaxMin extends HttpServlet {
    private static final long serialVersionUID = 1L;

    int numInputs = 0;
    boolean waitingForInputs = false;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        if (!waitingForInputs) {
            out.println("<html><body>");
            out.println("<h2>Enter the number of inputs:</h2>");
            out.println("<form method='post'>");
            out.println("Number of Inputs: <input type='text' name='count'/><br/>");
            out.println("<input type='submit' value='Submit'/>");
            out.println("</form>");
            out.println("</body></html>");
        } else {
            out.println("<html><body>");
            out.println("<h2>Enter " + numInputs + " numbers:</h2>");
            out.println("<form method='post'>");
            for (int i = 1; i <= numInputs; i++) {
                out.println("Number " + i + ": <input type='text' name='num" + i + "'/><br/>");
            }
            out.println("<input type='submit' value='Submit'/>");
            out.println("</form>");
            out.println("</body></html>");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        if (!waitingForInputs) {
            String countStr = request.getParameter("count");
            if (countStr != null && !countStr.isEmpty()) {
                numInputs = Integer.parseInt(countStr);
                waitingForInputs = true;
            }
            doGet(request, response); // Redisplay with input form
        } else {
            int[] numbers = new int[numInputs];
            boolean validInput = true;

            for (int i = 0; i < numInputs; i++) {
                String numStr = request.getParameter("num" + (i + 1));
                if (numStr == null || numStr.isEmpty()) {
                    validInput = false;
                    break;
                }
                numbers[i] = Integer.parseInt(numStr);
            }

            if (validInput) {
                int max = numbers[0];
                int min = numbers[0];

                for (int i = 1; i < numbers.length; i++) {
                    if (numbers[i] > max) max = numbers[i];
                    if (numbers[i] < min) min = numbers[i];
                }

                out.println("<html><body>");
                out.println("<h2>Result:</h2>");
                out.println("Largest Number: " + max + "<br/>");
                out.println("Smallest Number: " + min + "<br/>");
                out.println("<a href='FindMaxMin'>Try Again</a>");
                out.println("</body></html>");

                waitingForInputs = false;
                numInputs = 0;
            } else {
                out.println("<html><body>");
                out.println("<h2>Error: Please enter valid numbers for all inputs.</h2>");
                out.println("<a href='FindMaxMin'>Go Back</a>");
                out.println("</body></html>");
            }
        }
    }
}
